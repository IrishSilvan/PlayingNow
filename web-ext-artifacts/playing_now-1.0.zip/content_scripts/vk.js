function onRun() {
	console.log(`vk.com message`);
}

onRun();