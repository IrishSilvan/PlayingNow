function onRun() {
	var artist = document.body.getElementsByClassName("player-controls__artists")[0].getAttribute("title").toString();
	var title = document.body.getElementsByClassName("player-controls__title")[0].getAttribute("title").toString();
	console.log(artist + "-" + title);
}

addEventListener("click", onRun);